from django.apps import AppConfig


class TimetablesConfig(AppConfig):
    name = 'timetables'
