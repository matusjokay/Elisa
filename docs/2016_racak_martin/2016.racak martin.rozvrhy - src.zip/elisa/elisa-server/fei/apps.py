from django.apps import AppConfig


class FEIConfig(AppConfig):
    name = 'fei'
